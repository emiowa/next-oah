number: '3'

title: 'Big voids'

summary: 'We design them because we thought they are worthy to inhabit, nevertheless, they converted in unused spaces.'

text: 'Architects design based on a dream, an imaginary. Each project has a soul and a message to offer. We design areas that invite you to enter, that invite you to experience leisure and entertainment moments, places that were thought to enjoy in community. Nevertheless, the reality is different. The activities and social dynamics that present are not exactly what was imagined.'

question: 'Are our dreams coherent with the vision of the society with them?'