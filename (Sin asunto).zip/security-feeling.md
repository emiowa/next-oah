number: '11'

title: 'Security feeling'

summary: 'Some cities grow turning their backs to the road and public space, making the outside a dangerous environment.'

text: 'Security has been a complex issue to work from architecture and design. It seems that we have come to the conclusion that we must protect ourselves from the outside. Therefore, our solution was to lock ourselves up more and more avoiding the entrance of danger in our safe territory. Nevertheless, our daily routine demands moments in which we must leave it. The fact of having enclosed spaces in which we feel security caused us to no longer find tranquility outside.'

question: 'Could be possible with the architecture and the urban design offer to the community exterior spaces where they can have a security feeling?'