number: '2'

title: 'Sustainability?'

summary: 'How dangerous it is when humans think they are superior, when they think their interests are priorities.'

text: 'The subject of environmental care has gotten so strong that every time more people are betting on the design and construction of sustainable buildings, a very popular term nowadays. The common usage of this term has turned into a misconception by people who don’t really know or understand its meaning.'

question: 'Are "sustainable buildings" words that involve an awareness of environmental care or are they only attractive words to sell projects?'